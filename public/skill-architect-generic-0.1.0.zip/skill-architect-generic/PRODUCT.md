# Skill Architect

**通过架构重构，将长 `SKILL.md` 的 Token 消耗降低 50-60% 或更高。**

## 维护长 Skill 的用户看过来

你的 Skill 是不是每次对话都要加载上千行，Token 消耗越来越快？尝试精简描述、压缩提示词，但效果有限。因为问题不是文字太长，而是架构不合理。

Skill Architect 通过一次架构重构，把“每次全量加载”改为“总目录 + 路由索引 + 按需读取技能包”，让 Token 消耗显著下降，同时保留全部知识入口。

## 两次架构重构案例（脱敏）

同一份主 `SKILL.md` 的两轮效果，数据来自完整备份与效果检测，未包含具体 Skill 类型或私有资料。

- 第一轮：外移按书组织的大块判断尺，2034 行 → 836 行，减少 1198 行，约 59%，估算节省 17,300-23,100 tokens。
- 第二轮：外移方法网络、素材索引，836 行 → 586 行，减少 250 行，估算节省 8,400-11,200 tokens。
- 累计：2034 行 → 586 行，减少 1448 行，约 71%，估算节省 25,700-34,300 tokens。
- 完成时路由与测试：215 个活动技能包、355 条技能包路径、355 条原书路径、303 条测试提示词。

## 架构重构本身的好处

Token 节省是直接的、可量化的结果，但架构重构带来的改变远不止于此：

| 好处 | 说明 |
| --- | --- |
| 可维护性 | 单文件越长，改一处越容易影响全局；拆成技能包后，修改一个技能包不会影响其他内容。 |
| 可扩展性 | 新增技能包只需加入对应目录，不用修改主文件，不破坏已有结构。 |
| 可追溯性 | 每个技能包独立维护，改动影响范围清晰可查。 |
| 可回滚 | 单一技能包出问题只影响局部，整份主文件出问题则影响全局。 |
| 按需加载 | 每次只读取当前问题需要的技能包，而不是所有内容。 |
| 协作友好 | 多人维护时，不同人负责不同技能包，减少冲突。 |

## 解决的核心问题

| 问题 | Skill Architect 的解决方式 |
| --- | --- |
| 长 `SKILL.md` 每次对话整本常驻，Token 浪费 | 按需加载，只读需要的内容 |
| 内容外移后，目录、技能包、路由索引容易脱节 | 自动生成路由索引，保持同步 |
| 缺少备份时，结构性修改失败后难以恢复 | 修改前生成完整备份和 SHA-256 校验值 |
| 只有文件存在检查，缺少路由路径、测试命令等集成验证 | 提供完整的验证流程 |

## 核心能力

| 能力 | 说明 |
| --- | --- |
| 审计 | 统计 `SKILL.md` 的行数、章节、字符数，标出适合外移的大块内容 |
| 备份 | 修改前生成完整备份和 SHA-256 校验值 |
| 抽取 | 按起止标记或 JSON 配置，把指定章节抽成独立技能包，并替换为短说明 |
| 路由 | 扫描技能包并自动生成路由索引，后续可按需读取 |
| 验证 | 校验索引路径、测试集和自定义测试命令 |
| 回滚 | 校验备份后恢复到修改前版本 |

## 工作流程

1. 审计：`scripts/audit.py --skill SKILL.md`，输出可外移内容清单。
2. 确认：把可外移章节和保留内容交给用户确认。
3. 备份：`scripts/backup.py --skill SKILL.md --backup backup/`。
4. 抽取：`scripts/extract.py --skill SKILL.md --config slim-config.json`。
5. 路由：`scripts/build_index.py --pack-dir packs --index index.md --root .`。
6. 验证：`scripts/validate.py --skill SKILL.md --index index.md --root . --test-command "python3 scripts/self_test.py"`。
7. 回滚：`scripts/rollback.py --skill SKILL.md --backup backup/SKILL.md`。

每一步都有明确输入输出，支持回滚，风险可控。

## 长对话归纳场景

Skill Architect 不直接改写正在进行的对话，也不自动压缩聊天记录。它解决的是“把长对话沉淀成可复用技能”的架构问题：

1. 先把长对话中反复出现的问题、结论、判断尺和最佳实践整理成一份新的 `SKILL.md`。
2. 使用 `scripts/audit.py --skill SKILL.md` 找出哪些内容适合外移。
3. 备份后使用 `scripts/extract.py` 按主题拆成独立技能包。
4. 使用 `scripts/build_index.py` 建立路由，让以后同类问题按需读取。
5. 使用 `scripts/validate.py` 校验路径和测试，减少“知识还在但找不到”的风险。

已提供内置命令：

```bash
python3 scripts/conversation_architect.py --transcript 对话文件.md --output-dir conversation-output --skill-name project-notes
```

它会生成 `conversation-snapshot.md`、按话题拆分的技能包骨架和 `routing-index.md`，再由 Agent 根据快照填充核心结论、决策、待办和边界。

简化触发：

- 老对话：`帮我总结这个长对话`
- 新对话：`继续讨论 <问题>`

安全规则：完整对话 transcript 顶部必须声明 `conversation_scope: whole-dialog`；只总结某个主题时，才使用 `--scope topic`。默认拒绝用主题片段冒充完整对话。

新对话自动衔接：说“继续讨论 <问题>”后，Skill Architect 会先运行 `scripts/find_conversation_handoff.py` 自动查找最新快照和路由索引；找不到时再查找当前目录的 `conversation-output/`。

当前已开对话导入：说“把总结过的长对话导入当前对话，继续讨论 <问题>”，Skill Architect 会运行 `scripts/import_conversation_handoff.py --topic <问题>`，只读取最新快照、路由索引和匹配技能包，不复制旧对话完整历史。

跨用户转移：发送方运行 `scripts/export_conversation_handoff.py` 生成快照 zip，接收方运行 `scripts/import_conversation_handoff.py --source <zip> --topic <问题>` 导入；只传快照和技能包，不传完整对话。

继续规则：新对话或当前对话继续被迁移的问题时，先展示快照中的“老对话最后一段回答”，然后停止，由用户决定下一步；不自动执行老对话中的瘦身、修改、蒸馏等任务。

触发优先级：本机某个高优先级 Skill 项目可能接管“继续老版综合思维讨论”；此时提醒用户显式说“用 skill-architect 导入已总结长对话”。其他项目或新对话中优先运行 `find_conversation_handoff.py`。若触发不确定，不要长时间运行项目分析。

低消耗快速导入：直接说“快速导入已总结长对话”，Skill Architect 只运行导入脚本、展示最后一段回答并停止，不执行项目分析、路由优化或蒸馏。

当长对话调用过多个 Skill 时，可以把“什么场景触发哪个 Skill、各自边界、实际效果”沉淀成路由索引和多个技能包。Skill Architect 负责让这些入口保持同步、可验证、可回滚。

这样做的价值是：同一个 Agent 后续再遇到同类问题，不再依赖完整聊天记录，而是读取精简后的技能包，省去重复加载长对话的 Token 成本。

## 适用对象

- 维护超过数百行 `SKILL.md` 的 Codex / Claude Code / Cursor 用户。
- 需要把书籍、长判断尺、资料库拆成独立技能包的项目。
- 希望减少长技能文件上下文消耗，同时保留可验证、可回滚流程的团队或个人。

## 安装方式

Codex / Claude Code / Cursor 通用：

```bash
cp -r skill-architect <Codex 技能目录>/
cp -r skill-architect <Claude Code 技能目录>/
# 或放入通用技能目录 <你的技能目录>/
```

安装后，通过自然语言触发：

> 帮我瘦身这个 SKILL.md

## 版本与边界

- 当前版本：0.1.0。
- 许可证：CC BY-NC-SA 4.0。
- 跨 Agent 通用发布包：`skill-architect-generic-0.1.0.zip`。
- 默认外移哪些内容由用户确认，工具不自动删除用户内容。
- 验证主要检查索引路径、文件结构和测试命令，不保证业务语义完全不变。
- 对外发布遵循 CC BY-NC-SA 4.0，非商业用途。

Token 是硬成本，架构重构是长期收益。Skill Architect 帮你把两者都解决。
