#!/usr/bin/env python3
"""Package a conversation handoff into a small zip for transfer."""

import argparse
import datetime
import zipfile
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--snapshot-dir", default="conversation-output")
    parser.add_argument("--output", default="")
    args = parser.parse_args()

    snapshot_dir = Path(args.snapshot_dir)
    snapshot = snapshot_dir / "conversation-snapshot.md"
    index = snapshot_dir / "routing-index.md"
    if not snapshot.exists():
        raise SystemExit("SNAPSHOT_NOT_FOUND")
    if not index.exists():
        raise SystemExit("ROUTING_INDEX_NOT_FOUND")

    if args.output:
        output = Path(args.output)
    else:
        stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
        output = Path(f"skill-architect-handoff-{stamp}.zip")
    output.parent.mkdir(parents=True, exist_ok=True)

    files = [p for p in snapshot_dir.rglob("*") if p.is_file() and p.name != ".DS_Store"]
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in files:
            zf.write(path, path.relative_to(snapshot_dir).as_posix())

    print(f"output={output}")
    print(f"files={len(files)}")
    print("EXPORT_CONVERSATION_HANDOFF_OK")


if __name__ == "__main__":
    main()
